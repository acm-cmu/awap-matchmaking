def this_is_useful_1():
    return "I was useful 1"