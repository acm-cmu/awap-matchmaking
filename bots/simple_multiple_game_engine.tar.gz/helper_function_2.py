def this_is_useful_2():
    return "I was useful 2"